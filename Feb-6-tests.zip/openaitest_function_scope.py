import openai


openai.api_key = "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"

systemprompt = """
Your are an automated program repair tool for Solidity Smart Contracts. We only need the functions that concern the vulnerability. Don't skip any portions within the functions. Don't resolve dependencies.
"""

prompt = """
/// The following Solidity Smart Contract has been analyzed by smart contract analyzers. Here are the results.


/// 1. Semgrep Analysis Results
/// 1.1. Vulnerability: reentrancy:
/*
        require(_checkOnERC721Received(from, to, tokenId, _data), "ERC721: transfer to non ERC721Receiver implementer");
*/
///  Message:ERC721 onERC721Received() reentrancy
/// 1.2. Vulnerability: reentrancy:
/*
        require(_checkOnERC721Received(address(0), to, tokenId, _data), "ERC721: transfer to non ERC721Receiver implementer");
*/
///  Message:ERC721 onERC721Received() reentrancy


function _safeTransfer(address from, address to, uint256 tokenId, bytes memory _data) internal virtual {
    _transfer(from, to, tokenId);
    require(_checkOnERC721Received(from, to, tokenId, _data), "ERC721: transfer to non ERC721Receiver implementer");
}

function _safeMint(address to, uint256 tokenId, bytes memory _data) internal virtual {
    _mint(to, tokenId);
    require(_checkOnERC721Received(address(0), to, tokenId, _data), "ERC721: transfer to non ERC721Receiver implementer");
}
    


"""

response = openai.ChatCompletion.create(
    model="gpt-4-1106-preview",
    messages=[
        {"role": "system", "content": systemprompt},
        {"role": "user", "content": prompt}
    ],
    temperature=0.7,
    top_p=0.95,
    frequency_penalty=0,
    presence_penalty=0,
    n=10,
)

# Save all contents of the response in a folder to different files:
for i, message in enumerate(response.choices):
    with open(f"openaitest_{i}.sol", "w") as f:
        f.write(message['message']["content"])